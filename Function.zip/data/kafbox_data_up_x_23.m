% KAFBOX_DATA_LORENZ Data loader for Lorenz data set

function [X,Y,X_test,Y_test] = kafbox_data_up_x_23(data_opts)

pos2 = [500        400        200          150];

%--------------------------------------------------------------------------
% load data.mat;
% Data = G3535101(405242:408021,4)';
% % Data pretreatment
% j = 1; data = [];
% for i = 1:length(Data)
%     if ~isnan(Data(i))
%        data(j) = Data(i); j = j+1;
%     end
% end
% data = data';
% 
% figure; box on;
% pos3 = [500        400        700          225];
% plot(data); xlabel('Time/s'); ylabel('Amplitude/^o');
% set(gcf,'pos',pos3); setfontsize(10);
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
load ('E9_2.mat');

figure; box on; polar(x1,x2,'.'); set(gcf,'pos',pos2); setfontsize(10);
% 
figure; box on; polar(x3,x4,'.'); set(gcf,'pos',pos2); setfontsize(10);

Time = 180;
A = sqrt((x1-x3).^2+(x2-x4).^2);
N = ceil(length(A)/Time);
data = [];j = 1;
for i = 1:N
    if j+Time <= length(A)
        data(i) = mean(A(j:j+Time));
    else
        data(i) = mean(A(j:end));
    end
    j = j+Time;
end
data = data';

figure; box on;
plot(data,'LineWidth',1);
xlabel('Time [hour]'); ylabel('Amplitude');
set(gcf,'pos',pos2); setfontsize(10);
%--------------------------------------------------------------------------

% prediction horizon
horizon = 1;
if isfield(data_opts,'horizon')
    horizon = data_opts.horizon;
end

% construct signal
X = data(1:end-horizon); % input
Y = data(1+horizon:end); % desired output

X_test = [];
Y_test = [];
