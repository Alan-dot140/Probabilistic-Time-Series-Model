% Superclass for kernel adaptive filters.
%
% This file is part of the Kernel Adaptive Filtering Toolbox for Matlab.
% https://github.com/steven2358/kafbox/

classdef kernel_adaptive_filter < matlab.mixin.Copyable
    
end
