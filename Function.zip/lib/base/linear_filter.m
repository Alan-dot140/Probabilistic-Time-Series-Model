% Superclass for linear filters.
%
% This file is part of the Kernel Adaptive Filtering Toolbox for Matlab.
% https://github.com/steven2358/kafbox/

classdef linear_filter < base_estimator
    
end
